package com.example.quiz;

public class OpcionesItem {

    private String opcion;

    public OpcionesItem(String op){
        this.opcion=op;
    }

    public String getOpcion(){
        return opcion;
    }
}
